<?php //Main Application access point

//require_once "xataface//dataface-public-api.php"; 
//require_once "..//xataface//dataface-public-api.php"; 
require_once "xataface/dataface-public-api.php"; 

/* 
2012-06-21 made it generic so it works in both...

Windows:
require_once "C:\\p2\\websw\\xampp\\htdocs\\xataface\\dataface-public-api.php"; 
*/

/* 
Linux:
require_once "/var/www/xataface/dataface-public-api.php"; 
*/


//set default sort order. this is needed in 1.5x. to get it to work. 2012-06-21
// 
if ( !isset($_REQUEST['-sort']) and @$_REQUEST['-table'] == 'pr_downtime1' ){
    $_REQUEST['-sort'] = $_GET['-sort'] = 'completedtime desc';
   }


//df_init(__FILE__, "/xataface");
df_init(__FILE__, "xataface");
$app =& Dataface_Application::getInstance();

$app->display();


//changed to another approach 2012-06-14_Thu-09.46-AM. David Gleba. kdg54.
function isAdmin(){
        $auth =& Dataface_AuthenticationTool::getInstance();
        $user =& $auth->getLoggedInUser();
        if ( $user and $user->val('role') == 'ADMIN')  return true;
        return false;
    }

